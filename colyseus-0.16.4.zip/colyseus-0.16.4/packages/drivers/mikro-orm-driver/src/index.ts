// Not implemented
throw new Error("@colyseus/mikro-orm-driver not implemented.");