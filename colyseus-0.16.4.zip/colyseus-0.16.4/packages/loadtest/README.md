# @colyseus/loadtest

Utility tool for load testing Colyseus.

## License

MIT.
