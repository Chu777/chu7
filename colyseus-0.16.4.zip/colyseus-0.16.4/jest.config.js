/*
 * this is only used for @colyseus/testing
 */

export default {
  preset: 'ts-jest',
  testEnvironment: 'node'
};
