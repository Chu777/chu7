import { RoomCache } from "@colyseus/core";

export interface RoomData implements RoomCache {

}